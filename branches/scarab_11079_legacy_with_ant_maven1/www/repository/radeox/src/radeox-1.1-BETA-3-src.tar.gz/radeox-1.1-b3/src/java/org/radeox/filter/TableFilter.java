package org.radeox.filter;

/* ================================================================
 * Copyright (c) 2009 ScarabDevelopers.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 * any, must include the following acknowlegement: "This product includes
 * software developed by ScarabDevelopers <http://www.solitone.org/>."
 * Alternately, this acknowlegement may appear in the software itself, if
 * and wherever such third-party acknowlegements normally appear.
 *
 * 4. The hosted project names must not be used to endorse or promote
 * products derived from this software without prior written
 * permission. For written permission, please contact info@collab.net.
 *
 * 5. Products derived from this software may not use the "Tigris" or
 * "Scarab" names nor may "Tigris" or "Scarab" appear in their names without
 * prior written permission of Collab.Net.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL COLLAB.NET OR ITS CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals aka ScarabDevelopers
 */


/*
 * Table Filter implements creole-1.0 table creation. This class is heavily
 * dependent on the radeox-Tablebuilder class. (See for modifications in the
 * TableBuilder to support creole-1.0)
 *
 * @author Hussayn Dabbous
 */

import java.io.IOException;

import org.radeox.filter.context.FilterContext;
import org.radeox.filter.regex.LocaleRegexTokenFilter;
import org.radeox.macro.table.Table;
import org.radeox.macro.table.TableBuilder;
import org.radeox.regex.MatchResult;
import org.radeox.util.StringBufferWriter;

public class TableFilter extends LocaleRegexTokenFilter implements CacheFilter {
        
    protected String getLocaleKey() {
        return "filter.table";
    }

    public void handleMatch(StringBuffer buffer, MatchResult result, FilterContext context) {
        String content = result.group(0);
        if (null == content) throw new IllegalArgumentException("TableFilter: missing table content");
        content = content.trim() + "\n";

        Table table = TableBuilder.build(content);
        table.calc(); // calculate macros like =SUM(A1:A3)
        StringBufferWriter sbw = new StringBufferWriter(buffer);
        try {
            final boolean USE_CREOLE_STANDARD=true;
            table.appendTo(sbw, USE_CREOLE_STANDARD);
        } catch (IOException e) {
            throw new IllegalArgumentException("TableFilter: wrong syntax?, msg=["+e.getMessage()+"]");
        }
    }

}
