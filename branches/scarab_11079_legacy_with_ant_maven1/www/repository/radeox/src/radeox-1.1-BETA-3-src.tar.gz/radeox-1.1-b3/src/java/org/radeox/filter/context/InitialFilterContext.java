package org.radeox.filter.context;

/**
 * InitialFilterContext is used to
 * give the filter information after it's startup
 * (e.g. locales)
 *
 * @author Stephan J. Schmidt
 * @version $Id: InitialFilterContext.java,v 1.1 2003/08/11 13:19:57 stephan Exp $
 */

public interface InitialFilterContext {
}
