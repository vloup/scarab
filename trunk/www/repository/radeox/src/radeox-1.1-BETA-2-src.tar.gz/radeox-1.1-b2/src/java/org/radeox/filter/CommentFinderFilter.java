package org.radeox.filter;

/* ================================================================
 * Copyright (c) 2009 ScarabDevelopers.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 * any, must include the following acknowlegement: "This product includes
 * software developed by ScarabDevelopers <http://www.solitone.org/>."
 * Alternately, this acknowlegement may appear in the software itself, if
 * and wherever such third-party acknowlegements normally appear.
 *
 * 4. The hosted project names must not be used to endorse or promote
 * products derived from this software without prior written
 * permission. For written permission, please contact info@collab.net.
 *
 * 5. Products derived from this software may not use the 
 * "Scarab" names nor may "Scarab" appear in their names without
 * prior written permission of ScarabDevelopers.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL COLLAB.NET OR ITS CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals aka ScarabDevelopers
 */


/*
 * Comment Filter replaces {{{ anything }}} by a <div class="comment"> anything </div>
 * The regexp and the replacement are defined in radeox_markup.properties
 *
 * @author Hussayn Dabbous
 */

import org.radeox.filter.context.FilterContext;
import org.radeox.filter.regex.LocaleRegexTokenFilter;
import org.radeox.regex.MatchResult;

public class CommentFinderFilter extends LocaleRegexTokenFilter implements CacheFilter {
    
    public static final String COMMENT_ID = CommentFinderFilter.class.getName()+".commentCounter";
    private static final String COMMENT_PREPENDIX = "$(comment_";
    private static final String COMMENT_APPENDIX  = ")";
    
    protected String getLocaleKey() {
        return "filter.commentfinder";
    }

    public void handleMatch(StringBuffer buffer, MatchResult result, FilterContext context) {

        Integer commentId = getNextCommentId(context);
        String key        = COMMENT_PREPENDIX+commentId+COMMENT_APPENDIX;
        String content    = result.group(1);
        context.getRenderContext().set(key, content); // store the comment in the renderContext
        buffer.append(key); // and place a commentHandle into the outputbuffer
    }

    /**
     * Create a commentCounter handle.
     * We use the values map of the Filter Context as storage for comment snippets.
     * These comments will later be read from the CommentResolverFilter and placed into the 
     * finel render output.
     * @param context
     * @return
     */
    private Integer getNextCommentId(FilterContext context) {
        Integer commentCounter = (Integer)context.getRenderContext().get(COMMENT_ID);
        if (commentCounter == null)
        {
            commentCounter = new Integer(0);
        }
        commentCounter += 1;
        context.getRenderContext().set(COMMENT_ID, commentCounter);
        return commentCounter;
    }
}
