/*
 *      Copyright 2001-2004 Fraunhofer Gesellschaft, Munich, Germany, for its 
 *      Fraunhofer Institute Computer Architecture and Software Technology
 *      (FIRST), Berlin, Germany
 *      
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */


package org.radeox.macro.table;

import java.util.StringTokenizer;

/**
 * Built a table from a string
 *
 * @author stephan
 * @version $Id: TableBuilder.java,v 1.3 2003/10/06 08:30:02 stephan Exp $
 */

public class TableBuilder {

    private static final String CR          = "\r";
    private static final String EOL         = "\n";
    private static final String NEXT_COLUMN = "|";
    private static final String EMPTY_CELL  = " ";
    
  public static Table build(String content) {
    Table table = new Table();
    StringTokenizer tokenizer = new StringTokenizer(content, NEXT_COLUMN + EOL, true);
    String lastToken = null;
    boolean atBeginOfRow = true;
    
    while (tokenizer.hasMoreTokens()) {
        
      String token = getNextTableItem(tokenizer);

      if (CR.equals(token)) 
      {
          continue; // fully ignore "\r"
      }

      else if (EOL.equals(token)) 
      {
        // Handles "\n" - "|\n "
        if (atBeginOfRow)
        {
          table.addCell(" "); // add an empty cell, if table row is empty.
        }
        table.newRow(); // and create a new row 
        atBeginOfRow = true;
      }

      else if (!NEXT_COLUMN.equals(token)) 
      {
        table.addCell(token);
        atBeginOfRow=false;
      }
      
      // Now deal with NEXT_COLUMN marker

      else if (NEXT_COLUMN.equals(lastToken)) 
      {
        // Handles "||"
        table.addCell(EMPTY_CELL);
        atBeginOfRow=false;
      }
      lastToken = token;
    }
    return table;
  }

  private static String getNextTableItem(StringTokenizer tokenizer) {
    String token = tokenizer.nextToken();

      if(token.indexOf('[') != -1 && token.indexOf(']') == -1) {
        String linkToken = "";
	    while(token.indexOf(']') == -1 && tokenizer.hasMoreTokens()) {
	      linkToken += token;
	      token = tokenizer.nextToken();
	    }
	    token = linkToken + token;
      }
    return token;
  }
  
}
